public class AssertMe {
    public static void main(String [] args) {
        System.out.println("About to assert");
        assert System.out != null; // This assertion should never fail
        assert System.out == null : "I was meant to fail"; // This assertion should fail
        System.out.println("The assertion did not fire");
    }
}
